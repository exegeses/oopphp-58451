<?php
    require 'config/config.php';

    include 'includes/header.html';
    include 'includes/nav.php';
?>

    <main class="container py-3">
        <h1>Tema de la sección</h1>
    
    
    
    </main>
<?php
    include 'includes/footer.php';
?>